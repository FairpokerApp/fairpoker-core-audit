import {EventLog, EventLogs} from "../lib/texas-holdem/useEventLogs";
import {Message, Messages} from "../lib/useChatRoom";
import React, {useCallback, useEffect, useMemo, useRef, useState} from "react";
import PlayerAvatar from "./PlayerAvatar";
import DataTestIdAttributes from "../lib/types";
import {useHandRankLabel, useI18n} from "../lib/i18n";

function EventOrMessage(props: {
  myPlayerId: string;
  eventOrMessage: EventLog | Message;
  names: Map<string, string>;
  dataTestId?: string;
}) {
  const {t} = useI18n();
  const handRankLabel = useHandRankLabel();
  const em = props.eventOrMessage;

  const AvatarOrMe = (subProps: { whose: string }) => {
    return subProps.whose === props.myPlayerId
        ? <></>
        : <><PlayerAvatar title={props.names.get(subProps.whose)} playerId={subProps.whose}/></>
  }

  switch (em.type) {
    case 'message':
      return (
        <div className={em.whose === props.myPlayerId ? "message mime" : "message"} data-testid={props.dataTestId}>
          <AvatarOrMe whose={em.whose}/>
          <div className="name-and-message-text">
            <div className="name">
              {
                em.whose === props.myPlayerId
                  ? <>{t('me')}</>
                  : props.names.get(em.whose) || em.whose
              }
            </div>
            <div className="message-text">{em.text}</div>
          </div>
        </div>
      );
    case 'newRound':
      return (
        <div className="message system-notification" data-testid={props.dataTestId}>{t('roundStarted', {round: em.round})}</div>
      );
    case 'raise':
      return (
        <div className={em.playerId === props.myPlayerId ? "message mime system-notification" : "message system-notification"} data-testid={props.dataTestId}>
          <AvatarOrMe whose={em.playerId}/>{t('betAmount', {amount: `$${em.raisedAmount}`})}
          {
            em.allin && <b>&nbsp;{t('allIn')}</b>
          }
        </div>
      );
    case 'fold':
      return (
        <div className={em.playerId === props.myPlayerId ? "message mime system-notification" : "message system-notification"} data-testid={props.dataTestId}>
          <AvatarOrMe whose={em.playerId}/>
          {
            em.playerId === props.myPlayerId
              ? t('youFolded')
              : t('playerFolded', {player: props.names.get(em.playerId) ?? em.playerId})
          }
        </div>
      );
    case 'check':
      return (
        <div className={em.playerId === props.myPlayerId ? "message mime system-notification" : "message system-notification"} data-testid={props.dataTestId}>
          <AvatarOrMe whose={em.playerId}/>{t('check')}
        </div>
      );
    case 'winner':
      return (
        <div className="message system-notification" data-testid={props.dataTestId}>
          {
            em.result.how === 'LastOneWins' ? (
              <>
                <PlayerAvatar playerId={em.result.winner}/>:&nbsp;
                {
                  em.result.winner === props.myPlayerId
                    ? t('youWonByFold')
                    : t('youLostByFold', {player: props.names.get(em.result.winner) ?? em.result.winner})
                }
              </>
            ) : em.result.how === 'Voided' ? (
              <>{t('handVoided')}</>
            ) : (
              <>
                {
                  em.result.showdown[0].players.map(p => <PlayerAvatar key={p} playerId={p}/>)
                }
                :&nbsp;
                {
                  em.result.showdown[0].players.includes(props.myPlayerId)
                    ? t('youWonWith', {rank: handRankLabel(em.result.showdown[0].handValue)})
                    : t('playerWonWith', {
                      player: props.names.get(em.result.showdown[0].players[0]) ?? em.result.showdown[0].players[0],
                      rank: handRankLabel(em.result.showdown[0].handValue),
                    })
                }
              </>
            )
          }
        </div>
      );
    case 'fund':
      return (
        <div className={em.playerId === props.myPlayerId ? "message mime system-notification" : "message system-notification"} data-testid={props.dataTestId}>
          <PlayerAvatar playerId={em.playerId}/> {t('fund', {amount: `$${em.currentAmount}`})}&nbsp;
          {
            em.previousAmount && <>
              ({(em.currentAmount - em.previousAmount >= 0) ? '+' : '-'}${Math.abs(em.currentAmount - em.previousAmount)})
            </>
          }
          {
            em.borrowed && <>({t('borrowed')})</>
          }
        </div>
      );
  }
}

export default function MessageBar(props: DataTestIdAttributes & {
  playerId: string;
  eventLogs: EventLogs;
  messages: Messages;
  onMessage?: (message: string) => void;
  names: Map<string, string>;
  defaultCollapsed?: boolean;
}) {
  const {t} = useI18n();
  const {
    playerId,
    eventLogs,
    messages,
    onMessage,
    names,
  } = props;
  const eventsAndMessage: Array<EventLog | Message> = useMemo(() => {
    const merged = [];
    let i = 0;
    let j = 0;
    while (i < eventLogs.length || j < messages.length) {
      if (i >= eventLogs.length) {
        merged.push(messages[j++]);
      } else if (j >= messages.length || eventLogs[i].timestamp <= messages[j].timestamp) {
        merged.push(eventLogs[i++]);
      } else {
        merged.push(messages[j++]);
      }
    }
    return merged;
  }, [eventLogs, messages]);

  const [collapsed, setCollapsed] = useState(props.defaultCollapsed ?? true);
  const flipCollapsed = useCallback(() => setCollapsed(collapsed => !collapsed), []);

  const [readMessageCount, setReadMessageCount] = useState<number>(0);
  useEffect(() => {
    if (!collapsed) {
      setReadMessageCount(messages.length);
    }
  }, [messages, collapsed]);
  const unreadMessageCount = useMemo(() => messages.length - readMessageCount, [messages, readMessageCount]);

  const [inputValue, setInputValue] = useState('');

  const handleInputChange: React.ChangeEventHandler<HTMLInputElement> = useCallback(e => {
    setInputValue(e.target.value);
  }, []);

  const handleInputKeyUp: React.KeyboardEventHandler<HTMLInputElement>  = useCallback(e => {
    if (e.key === 'Enter' && inputValue) {
      onMessage?.(inputValue);
      setInputValue('');
    }
  }, [inputValue, onMessage]);

  const messagesDivRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const messagesDiv = messagesDivRef.current;
    messagesDiv?.scrollTo?.(0, messagesDiv.scrollHeight);
  }, [messages, eventLogs]);

  return (
    <div className={collapsed ? "message-bar collapsed" :  "message-bar"} data-testid={props['data-testid'] ?? 'message-bar'}>
      <div className="title-bar" onClick={flipCollapsed} data-testid="title-bar">
        <div className="profile">
          <PlayerAvatar playerId={playerId}/>
          <h4>{t('messages')}</h4>
          {
            (collapsed && unreadMessageCount > 0) && <span className="badge">{unreadMessageCount > 99 ? '99+' : unreadMessageCount}</span>
          }
        </div>
        <div className="icon">
          <p style={{transform: collapsed ? 'rotate(-90deg)' : 'rotate(90deg)'}}>❮</p>
        </div>
      </div>
      {
        eventsAndMessage.length === 0
          ? <div className="no-messages" data-testid="no-messages">{t('noMessages')}</div>
          : (
            <div ref={messagesDivRef} className="messages">
              {
                eventsAndMessage.map((em, i) => <EventOrMessage
                  key={i}
                  myPlayerId={playerId}
                  names={names}
                  eventOrMessage={em}
                  dataTestId={`message-${i}`}
                />)
              }
            </div>
          )
      }
      <input className="message-input"
             type="text"
             placeholder={t('typeMessage')}
             value={inputValue}
             onChange={handleInputChange}
             onKeyUp={handleInputKeyUp}
             data-testid="message-input"
      />
    </div>
  );
}
